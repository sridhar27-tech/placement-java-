"""Tests for Client and AsyncClient classes."""

import json
from unittest.mock import AsyncMock, MagicMock, call, patch

import pytest

from perplexity.client import Client
from perplexity.config import SSE_ASK_HEADERS
from perplexity.exceptions import (
    AuthenticationError,
    FileUploadError,
    IncompleteResponseError,
    NetworkError,
    RateLimitError,
    ValidationError,
)
from perplexity_async.client import Client as AsyncClient


def make_sse_frames(answer: str = "OK") -> tuple[dict, list[bytes]]:
    """Build frames matching Perplexity's current combined end event."""
    message = {
        "blocks": [
            {
                "intended_usage": "ask_text",
                "markdown_block": {"answer": answer},
            }
        ]
    }
    frames = [
        f"event: message\r\ndata: {json.dumps(message)}".encode("utf-8"),
        b"event: end_of_stream\r\ndata: {}",
    ]
    expected = {**message, "answer": answer, "chunks": []}
    return expected, frames


def make_sync_response(frames: list[bytes]) -> MagicMock:
    response = MagicMock(status_code=200)
    response.iter_lines.return_value = frames
    return response


def make_async_response(frames: list[bytes]) -> MagicMock:
    response = MagicMock(status_code=200)

    async def aiter_lines(*args, **kwargs):
        for frame in frames:
            yield frame

    response.aiter_lines = aiter_lines
    return response


def test_client_init_defaults() -> None:
    with patch("curl_cffi.requests.Session.get") as mock_get:
        mock_get.return_value = MagicMock(ok=True)
        cli = Client()
        assert not cli.own
        assert cli.copilot == 0
        assert cli.file_upload == 0

        cli_auth = Client(cookies={"session": "test"})
        assert cli_auth.own
        assert cli_auth.copilot == float("inf")
        assert cli_auth.file_upload == float("inf")


def test_client_search_validation() -> None:
    with patch("curl_cffi.requests.Session.get") as mock_get:
        mock_get.return_value = MagicMock(ok=True)
        cli = Client()

        with pytest.raises(ValidationError, match="Invalid mode"):
            cli.search("test", mode="non_existent")

        with pytest.raises(ValidationError, match="requires an account"):
            cli.search("test", mode="pro", model="sonar")

        with pytest.raises(ValidationError, match="No remaining enhanced queries"):
            cli.search("test", mode="pro")


def test_client_search_success_mock() -> None:
    with (
        patch("curl_cffi.requests.Session.get") as mock_get,
        patch("curl_cffi.requests.Session.post") as mock_post,
    ):
        mock_get.return_value = MagicMock(ok=True)

        final_data = json.dumps({"answer": "Python is a language", "chunks": []})
        nested_text = json.dumps([{"step_type": "FINAL", "content": {"answer": final_data}}])
        mock_response_data = {
            "text": nested_text,
            "blocks": [
                {"intended_usage": "ask_text", "markdown_block": {"answer": "Python is a language"}}
            ],
        }

        sse_chunk = (
            f"data: {json.dumps(mock_response_data)}\r\n\r\nevent: end_of_stream\r\n\r\n".encode(
                "utf-8"
            )
        )

        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.iter_lines.return_value = [
            f"data: {json.dumps(mock_response_data)}".encode("utf-8"),
            b"event: end_of_stream",
        ]
        mock_post.return_value = mock_resp

        cli = Client()
        result = cli.search("What is Python?", mode="auto")
        assert isinstance(result, dict)
        assert result.get("answer") == "Python is a language"


def test_client_handles_combined_end_of_stream_frame() -> None:
    with (
        patch("curl_cffi.requests.Session.get", return_value=MagicMock(ok=True)),
        patch("curl_cffi.requests.Session.post") as mock_post,
    ):
        expected, frames = make_sse_frames()
        mock_post.return_value = make_sync_response(frames)

        cli = Client()
        result = cli.search("test")
        streamed = list(cli.search("test", stream=True))

        # parse_nested_json_response enriches blocks-format responses with a
        # top-level "answer" key so callers can use response["answer"] directly.
        assert result["blocks"] == expected["blocks"]
        assert result["answer"] == "OK"
        assert streamed[0]["blocks"] == expected["blocks"]
        assert streamed[0]["answer"] == "OK"


def test_client_strict_completion_and_provider_timeout() -> None:
    with (
        patch("curl_cffi.requests.Session.get", return_value=MagicMock(ok=True)),
        patch("curl_cffi.requests.Session.post") as mock_post,
    ):
        partial = {"answer": "partial", "backend_uuid": "diagnostic-only"}
        mock_post.return_value = make_sync_response(
            [f"data: {json.dumps(partial)}".encode("utf-8")]
        )
        observed = []
        cli = Client()

        # The established default remains permissive on premature EOF.
        assert cli.search("test")["answer"] == "partial"
        with pytest.raises(IncompleteResponseError, match="before terminal"):
            cli.search(
                "test",
                require_complete=True,
                provider_timeout=321,
                event_callback=observed.append,
            )

        assert observed[-1]["backend_uuid"] == "diagnostic-only"
        assert mock_post.call_args.kwargs["timeout"] == 321


@pytest.mark.parametrize("provider_timeout", [0, -1, float("nan"), float("inf"), True])
def test_client_rejects_invalid_provider_timeout(provider_timeout) -> None:
    with patch("curl_cffi.requests.Session.get", return_value=MagicMock(ok=True)):
        cli = Client()
        with pytest.raises(ValueError, match="finite number greater than zero"):
            cli.search("test", provider_timeout=provider_timeout)


@pytest.mark.asyncio
async def test_async_client_handles_combined_end_of_stream_frame() -> None:
    expected, frames = make_sse_frames()

    with patch("perplexity_async.client.requests.AsyncSession") as session_cls:
        session = MagicMock()
        session.get = AsyncMock(return_value=MagicMock(ok=True))
        session.post = AsyncMock(return_value=make_async_response(frames))
        session_cls.return_value = session

        cli = await AsyncClient()
        result = await cli.search("test")
        assert result["blocks"] == expected["blocks"]
        assert result["answer"] == "OK"

        stream = await cli.search("test", stream=True)
        streamed = [chunk async for chunk in stream]
        assert streamed[0]["blocks"] == expected["blocks"]
        assert streamed[0]["answer"] == "OK"


def test_client_search_http_errors() -> None:
    with (
        patch("curl_cffi.requests.Session.get") as mock_get,
        patch("curl_cffi.requests.Session.post") as mock_post,
    ):
        mock_get.return_value = MagicMock(ok=True)

        cli = Client()

        # Test 429 RateLimitError
        mock_429 = MagicMock(status_code=429)
        mock_post.return_value = mock_429
        with pytest.raises(RateLimitError):
            cli.search("test")

        # Test 403 AuthenticationError
        mock_403 = MagicMock(status_code=403)
        mock_post.return_value = mock_403
        with pytest.raises(AuthenticationError):
            cli.search("test")

        # Test 500 NetworkError
        mock_500 = MagicMock(status_code=500)
        mock_post.return_value = mock_500
        with pytest.raises(NetworkError):
            cli.search("test")


def test_client_search_uses_sse_headers() -> None:
    """search() must pass SSE_ASK_HEADERS to the perplexity_ask POST so the
    request looks like a browser fetch() call rather than a page navigation,
    which is the primary cause of Perplexity blocking the request (issue #70)."""
    with (
        patch("curl_cffi.requests.Session.get") as mock_get,
        patch("curl_cffi.requests.Session.post") as mock_post,
    ):
        mock_get.return_value = MagicMock(ok=True)

        final_data = json.dumps({"answer": "test", "chunks": []})
        nested_text = json.dumps([{"step_type": "FINAL", "content": {"answer": final_data}}])
        mock_response_data = {
            "text": nested_text,
            "blocks": [{"intended_usage": "ask_text", "markdown_block": {"answer": "test"}}],
        }
        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.iter_lines.return_value = [
            f"data: {json.dumps(mock_response_data)}".encode("utf-8"),
            b"event: end_of_stream",
        ]
        mock_post.return_value = mock_resp

        cli = Client()
        cli.search("hello")

        # The last POST call (to ENDPOINT_SSE_ASK) must carry SSE_ASK_HEADERS.
        sse_call_kwargs = mock_post.call_args_list[-1][1]
        assert sse_call_kwargs.get("headers") == SSE_ASK_HEADERS, (
            "search() did not pass SSE_ASK_HEADERS to the perplexity_ask POST; "
            "stale sec-fetch-mode/dest values will be rejected by Perplexity's anti-bot layer"
        )
